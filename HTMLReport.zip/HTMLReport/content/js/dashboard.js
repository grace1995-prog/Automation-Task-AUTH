/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 93.10344827586206, "KoPercent": 6.896551724137931};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5954545454545455, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.8, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-signature-capture-en.json"], "isController": false}, {"data": [0.0, 500, 1500, "https://portaltest.mtn.ci/auth/authenticate/basic"], "isController": false}, {"data": [0.7, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-barcode-scanner-en.json"], "isController": false}, {"data": [0.95, 500, 1500, "https://portaltest.mtn.ci/registration/analytics?panelName=ENROLMENT_TYPE_TREND"], "isController": false}, {"data": [0.4, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-verified-field-en.json"], "isController": false}, {"data": [0.65, 500, 1500, "login"], "isController": true}, {"data": [0.65, 500, 1500, "https://portaltest.mtn.ci/platform-user/role-group/list?pageNo=1&pageSize=10"], "isController": false}, {"data": [0.85, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-subscriber-reg-details-en.json"], "isController": false}, {"data": [0.75, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-searchable-dropdown-en.json"], "isController": false}, {"data": [0.0, 500, 1500, "https://portaltest.mtn.ci/platform-user/roles/list"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.6, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-otp-verification-en.json"], "isController": false}, {"data": [0.85, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-subscriber-reg-panel-en.json"], "isController": false}, {"data": [1.0, 500, 1500, "https://portaltest.mtn.ci/registration/analytics?panelName=REGISTRATION_SUMMARY"], "isController": false}, {"data": [0.15, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-fingerprint-en.json"], "isController": false}, {"data": [0.45, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-form-preview-en.json"], "isController": false}, {"data": [0.55, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-form-builder-en.json"], "isController": false}, {"data": [0.95, 500, 1500, "https://portaltest.mtn.ci/registration/analytics?panelName=MANAGER_PERFORMANCE"], "isController": false}, {"data": [0.9, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-form-view-en.json"], "isController": false}, {"data": [0.0, 500, 1500, "https://portaltest.mtn.ci/platform-user/role-group"], "isController": false}, {"data": [1.0, 500, 1500, "https://portaltest.mtn.ci/registration/analytics?panelName=REGISTRATION_USE_CASES"], "isController": false}, {"data": [0.95, 500, 1500, "https://portaltest.mtn.ci/registration/analytics?panelName=STATUS_TREND"], "isController": false}, {"data": [0.3, 500, 1500, "https://jsonip.com/"], "isController": false}, {"data": [0.2, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/en.json"], "isController": false}, {"data": [1.0, 500, 1500, "https://portaltest.mtn.ci/registration/analytics?panelName=OPERATORS_AND_DEVICE_SUMMARY"], "isController": false}, {"data": [0.9, 500, 1500, "https://portaltest.mtn.ci/registration/analytics?panelName=OPERATOR_PERFORMANCE"], "isController": false}, {"data": [0.85, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-custom-table-en.json"], "isController": false}, {"data": [0.0, 500, 1500, "Select role"], "isController": true}, {"data": [0.35, 500, 1500, "https://portaltest.mtn.ci/assets/i18n/sfx-portrait-capture-en.json"], "isController": false}, {"data": [0.9666666666666667, 500, 1500, "https://portaltest.mtn.ci/api/internationalization/get-user-default-language"], "isController": false}, {"data": [0.0, 500, 1500, "rolegroup"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 290, 20, 6.896551724137931, 758.5793103448274, 249, 3695, 440.5, 1716.9000000000024, 2420.849999999999, 3507.159999999997, 12.329931972789115, 119.41715162627551, 43.10078523596939], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-signature-capture-en.json", 10, 0, 0.0, 513.3, 255, 851, 439.5, 844.7, 851.0, 851.0, 2.774694783573807, 1.6122494103773584, 9.936333761098778], "isController": false}, {"data": ["https://portaltest.mtn.ci/auth/authenticate/basic", 10, 0, 0.0, 3113.7, 2233, 3695, 3182.5, 3687.5, 3695.0, 3695.0, 2.3014959723820483, 7.374226841196778, 8.626114787111623], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-barcode-scanner-en.json", 10, 0, 0.0, 524.9000000000001, 252, 842, 557.5, 838.7, 842.0, 842.0, 2.6659557451346307, 1.1741660557184752, 9.54172637296721], "isController": false}, {"data": ["https://portaltest.mtn.ci/registration/analytics?panelName=ENROLMENT_TYPE_TREND", 10, 0, 0.0, 400.4, 335, 745, 368.5, 709.4000000000001, 745.0, 745.0, 3.852080123266564, 20.716216053543913, 13.94121966486903], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-verified-field-en.json", 10, 0, 0.0, 1299.3000000000002, 859, 2153, 1192.5, 2151.2, 2153.0, 2153.0, 1.3852334118298935, 25.17634670660756, 4.956538301703837], "isController": false}, {"data": ["login", 10, 0, 0.0, 648.8000000000001, 330, 1112, 655.0, 1098.5, 1112.0, 1112.0, 2.9154518950437316, 15.283345481049562, 10.466016763848396], "isController": true}, {"data": ["https://portaltest.mtn.ci/platform-user/role-group/list?pageNo=1&pageSize=10", 10, 0, 0.0, 648.8000000000001, 330, 1112, 655.0, 1098.5, 1112.0, 1112.0, 2.9154518950437316, 15.283345481049562, 10.466016763848396], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-subscriber-reg-details-en.json", 10, 0, 0.0, 440.20000000000005, 263, 851, 375.5, 827.8000000000001, 851.0, 851.0, 2.7685492801771874, 14.045521006367663, 9.927844684385382], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-searchable-dropdown-en.json", 10, 0, 0.0, 543.1999999999999, 263, 944, 517.5, 935.3000000000001, 944.0, 944.0, 2.592016588906169, 0.9821312856402281, 9.287215688180405], "isController": false}, {"data": ["https://portaltest.mtn.ci/platform-user/roles/list", 10, 10, 100.0, 548.2, 268, 851, 547.0, 846.8, 851.0, 851.0, 2.775464890369137, 0.8646223633083541, 9.893014501804052], "isController": false}, {"data": ["Test", 10, 0, 0.0, 8087.9, 6952, 9596, 7959.0, 9544.0, 9596.0, 9596.0, 1.0224948875255624, 34.723886439161554, 41.371101738241315], "isController": true}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-otp-verification-en.json", 10, 0, 0.0, 792.7, 266, 1081, 857.5, 1078.7, 1081.0, 1081.0, 2.3255813953488373, 2.152979651162791, 8.32576308139535], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-subscriber-reg-panel-en.json", 10, 0, 0.0, 438.0, 287, 809, 315.5, 805.5, 809.0, 809.0, 2.8401022436807724, 5.81888135472877, 10.178882064754331], "isController": false}, {"data": ["https://portaltest.mtn.ci/registration/analytics?panelName=REGISTRATION_SUMMARY", 10, 0, 0.0, 348.90000000000003, 310, 421, 347.0, 416.90000000000003, 421.0, 421.0, 4.422821760283061, 19.12956794559929, 16.006813909774436], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-fingerprint-en.json", 10, 0, 0.0, 1735.4, 909, 2388, 1676.0, 2382.5, 2388.0, 2388.0, 1.3121637580370031, 62.758332239863535, 4.691241716966277], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-form-preview-en.json", 10, 0, 0.0, 1180.9, 763, 1873, 1123.5, 1822.7000000000003, 1873.0, 1873.0, 1.2827090815802975, 66.92634844792201, 4.587188141354541], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-form-builder-en.json", 10, 0, 0.0, 806.0999999999999, 377, 2135, 632.0, 2025.5000000000005, 2135.0, 2135.0, 1.8162005085361426, 73.28120743280058, 6.49504517798765], "isController": false}, {"data": ["https://portaltest.mtn.ci/registration/analytics?panelName=MANAGER_PERFORMANCE", 10, 0, 0.0, 356.09999999999997, 293, 544, 325.5, 533.9000000000001, 544.0, 544.0, 3.4891835310537336, 13.305919617934403, 12.62443845952547], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-form-view-en.json", 10, 0, 0.0, 399.2, 271, 858, 301.5, 836.9000000000001, 858.0, 858.0, 3.026634382566586, 4.469014830508475, 10.81489766192494], "isController": false}, {"data": ["https://portaltest.mtn.ci/platform-user/role-group", 10, 10, 100.0, 551.9, 279, 851, 512.0, 851.0, 851.0, 851.0, 3.0553009471432935, 0.9517978536510846, 11.212715780629392], "isController": false}, {"data": ["https://portaltest.mtn.ci/registration/analytics?panelName=REGISTRATION_USE_CASES", 10, 0, 0.0, 343.9, 304, 392, 340.5, 389.0, 392.0, 392.0, 4.595588235294118, 14.617022346047793, 16.641055836397058], "isController": false}, {"data": ["https://portaltest.mtn.ci/registration/analytics?panelName=STATUS_TREND", 10, 0, 0.0, 351.99999999999994, 281, 543, 324.0, 528.2, 543.0, 543.0, 3.779289493575208, 13.781120086923659, 13.648254440665156], "isController": false}, {"data": ["https://jsonip.com/", 10, 0, 0.0, 1490.2, 749, 3372, 1239.5, 3251.0000000000005, 3372.0, 3372.0, 2.6062027625749282, 2.0895434258535315, 1.3260074602554077], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/en.json", 10, 0, 0.0, 1831.6000000000001, 695, 3083, 1679.5, 3079.4, 3083.0, 3083.0, 1.6173378618793468, 60.59804858078603, 5.757027838427947], "isController": false}, {"data": ["https://portaltest.mtn.ci/registration/analytics?panelName=OPERATORS_AND_DEVICE_SUMMARY", 10, 0, 0.0, 342.9, 306, 400, 333.5, 398.6, 400.0, 400.0, 4.614674665436087, 22.86607348869405, 16.737208698661746], "isController": false}, {"data": ["https://portaltest.mtn.ci/registration/analytics?panelName=OPERATOR_PERFORMANCE", 10, 0, 0.0, 389.1, 304, 610, 335.5, 606.5, 610.0, 610.0, 3.5398230088495577, 13.75829646017699, 12.811117256637168], "isController": false}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-custom-table-en.json", 10, 0, 0.0, 489.9, 287, 851, 440.0, 850.1, 851.0, 851.0, 2.523977788995457, 1.3063556915699142, 9.026178382130237], "isController": false}, {"data": ["Select role", 10, 10, 100.0, 551.9, 279, 851, 512.0, 851.0, 851.0, 851.0, 3.0553009471432935, 0.9517978536510846, 11.212715780629392], "isController": true}, {"data": ["https://portaltest.mtn.ci/assets/i18n/sfx-portrait-capture-en.json", 10, 0, 0.0, 1167.3000000000002, 685, 2036, 1018.0, 2016.0, 2036.0, 2036.0, 1.349345567399811, 45.346708018486034, 4.830762548913777], "isController": false}, {"data": ["https://portaltest.mtn.ci/api/internationalization/get-user-default-language", 30, 0, 0.0, 316.9, 249, 612, 292.0, 393.8000000000001, 595.5, 612.0, 6.302521008403361, 1.6146106880252102, 22.83432904411765], "isController": false}, {"data": ["rolegroup", 10, 10, 100.0, 12710.199999999999, 11486, 13578, 12724.5, 13570.2, 13578.0, 13578.0, 0.636983247340595, 153.73939024778647, 34.17564414930887], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["401/Unauthorized", 20, 100.0, 6.896551724137931], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 290, 20, "401/Unauthorized", 20, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://portaltest.mtn.ci/platform-user/roles/list", 10, 10, "401/Unauthorized", 10, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://portaltest.mtn.ci/platform-user/role-group", 10, 10, "401/Unauthorized", 10, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
